package BugReportDownLoad;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class BugReport {

	/*
	 * get the link of repositories in the start page
	 * 
	 * return value : all link of each repository's bug report 
	 */
	
	public static int numberCnt = 0;
	public ArrayList<String> getRepository(String startPath) {
		ArrayList<String> repositoryLink = new ArrayList<>();
		String Content = URLParser.getURLContent(startPath, "utf-8");
		Pattern p = Pattern.compile("<a href=\"([\\S]+?)\" class=\"v-align-middle\">");
		Matcher m = p.matcher(Content);
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				repositoryLink.add(m.group(1).replaceFirst("/", ""));
			}
		}
		return repositoryLink;
	}
	
	static class MyRunable implements Runnable {

		public String urlPath;
		public String reposityry;
		public String[] aimlabel;
		public String rootPath;
		public MyRunable(String reposityry,String[] labels, String rootPath) {
			this.reposityry = reposityry;
			this.aimlabel = labels;
			this.rootPath = rootPath;
		}

		@Override
		public void run() {
			URLParser.print(reposityry, aimlabel, rootPath);
		}
	}
	
	public static void DownLoadMode1() throws InterruptedException{
		ArrayList<Thread> ThreadList = new ArrayList<>();
		String rootPath = "D:\\PolyU\\IEEE-Desktop-Mobile\\dataset-100Apps\\desktop\\";

		rootPath = "D:\\PolyU\\IEEE-Desktop-Mobile\\dataset-100Apps\\desktop\\";

		for (int idx = 1; idx <= 9; idx ++) {
				String startPath = "https://github.com/search?o=desc&p=" + String.valueOf(idx)
						+ "&q=desktop&ref=searchresults&s=stars&type=Repositories";
				System.out.println(startPath);
				BugReport br = new BugReport();
				ArrayList<String> reposityries = br.getRepository(startPath);
				
				for(String str : reposityries){
					System.out.println(str);
					Thread thread = new Thread(new MyRunable(str,null, rootPath));
					thread.start();
					ThreadList.add(thread);
				}
				
		}
		for(Thread t : ThreadList){
			t.join();
		}
	}
	
	public static void DownLoadMode2() throws InterruptedException{
		ArrayList<Thread> ThreadList = new ArrayList<>();
		String[] DownLoadList = {"atom/atom", "adobe/brackets","harvesthq/chosen","docker/docker","gitlabhq/gitlabhq",
				"Homebrew/legacy-homebrew", "lodash/lodash","robbyrussell/oh-my-zsh", "select2/select2","socketio/socket.io",
				"bumptech/glide","facebook/fresco","PhilJay/MPAndroidChart","square/picasso"};	
		String rootPath = "D:\\PolyU\\IEEE-Desktop-Mobile\\dataset-100Apps\\desktop\\";
		for(String str : DownLoadList){
			String[] labels = null;
//			if(str.equals("/AntennaPod/AntennaPod")){
//				String[] tmp = {"\"Feature+Request\"","enhancement"};
//				labels = tmp;
//			}
//			if(str.equals("/Automattic/simplenote-android") || str.equals("/k9mail/k-9")|| str.equals("/OneBusAway/onebusaway-android")
//					|| str.equals("/UweTrottmann/SeriesGuide")){
//				String[] tmp = {"enhancement"};
//				labels = tmp;
//			}
//			if(str.equals("/cgeo/cgeo")){
//				String[] tmp = {"\"Feature+Request\"",""};
//				labels = tmp;
//			}
//			if(str.equals("/chrislacy/TweetLanes")){
//				String[] tmp = {"\"Approved+Enhancement\"","\"Proposed+Enhancement\""};
//				labels = tmp;
//			}
//			if(str.equals("/TwidereProject/Twidere-Android")){
//				String[] tmp = {"type%3Aenhancement","type%3Afeature-request"};
//				labels = tmp;
//			}
//			if(str.equals("/WhisperSystems/Signal-Android")){
//				String[] tmp = {"performance","feature"};
//				labels = tmp;
//			}
//			if(str.equals("/wordpress-mobile/WordPress-Android")){
//				String[] tmp = {"\"Mobile+Request\"","\"%5BType%5D+Enhancement\"","Performance"};
//				labels = tmp;
//			}
				
			Thread thread = new Thread(new MyRunable(str,labels,rootPath));
			thread.start();
			ThreadList.add(thread);
		}	
		
		for(Thread t : ThreadList){
			t.join();
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		DownLoadMode1(); //download by rank and label is bug
//		DownLoadMode2(); //the project and label is provide by us
		System.out.println("total bug report number : " + BugReport.numberCnt);
	}

}
