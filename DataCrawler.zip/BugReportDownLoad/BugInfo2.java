package BugReportDownLoad;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BugInfo2 {
	private String title;
	private String bugID;
	private String BR_url;
	private ArrayList<String> commters;
	private ArrayList<String> commtents;
	private ArrayList<String> labels;
	private String developer;
	private Date openTime;
	private Date closeTime;
	private int num_Comments;
	private StringBuilder description;
	private String totalContent;
	private String assignees;
	private Document doc;
	
	public BugInfo2(String content,String BR_url) {
		this.BR_url = BR_url;
		this.doc = Jsoup.parseBodyFragment(content);
		this.totalContent = content;
		setTitleandBugID();
		setDeveloper();
		setLabels();
		setAssignees();
		setCommters();
		setOpenTime();
		setClosedTime();
		setDescriptionAndComments();
		
	}

	public String getTitle() {
		return title;
	}

	public String getBugID() {
		return bugID;
	}

	public String getDeveloper() {
		return developer;
	}

	public ArrayList<String> getCommters() {
		return commters;
	}
	
	public ArrayList<String> getLabels() {
		return labels;
	}

	public Date getOpenTime() {
		return openTime;
	}

	public int getNum_Comments() {
		return num_Comments;
	}

	public StringBuilder getDescription() {
		return description;
	}

	public void setTitleandBugID() {
		String title_and_id = doc.title();
		String temp[] = title_and_id.split("��");
		this.title = temp[0];
		this.bugID = temp[1];
	}

	public void setLabels() {
		this.labels = new ArrayList<>();
		Elements content = doc.select("div.labels");
		for(Element ele : content){
			if(ele.text().equals("None yet")){
				this.labels.add("None yet");
				break;
			}
			Elements eLabels = ele.getElementsByTag("a");
			for(Element lb : eLabels)
				this.labels.add(lb.text());
		}
	}
	
	public void setCommters() {
		
		this.commters = new ArrayList<>();
		int num_dev = 0;
		Elements content = doc.select("div.timeline-comment-header-text");
		for(Element ele : content){
			this.commters.add(ele.text().split(" ")[0]);
		}
		this.num_Comments = commters.size() - num_dev;
	}

	public void setDeveloper() {
		Pattern p = Pattern
				.compile("class=\"author\">([\\s\\S]+?)</a>[\\s]+?opened this");
		Matcher m = p.matcher(totalContent);
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				this.developer = m.group(1);
			}
		}
	}
	
	private void setAssignees(){
		Pattern p = Pattern.compile("class=\"assignee css-truncate-target\">([ \\S]+?)</");
		Matcher m = p.matcher(totalContent);
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				this.assignees = m.group(1);
			}
		}
	}

	public String getAssignees(){
		return this.assignees;
	}

	private Date setCorretDate(String date_temp) {
			
		date_temp = date_temp.replace('T', ' ');
		Date CorretDate = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			CorretDate = sdf.parse(date_temp);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return CorretDate;
	}

	public void setOpenTime() {
		Pattern p = Pattern.compile("opened this.+?datetime=\"(.+?)\"");
		Matcher m = p.matcher(totalContent);
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				this.openTime = setCorretDate(m.group(1));
			}
		}
	}
	
	private void setClosedTime(){
		Pattern p = Pattern.compile("closed this.+?<relative-time.+?datetime=\"(.+)\">");
		Matcher m = p.matcher(totalContent);
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				this.closeTime = setCorretDate(m.group(1));
			}
		}
	}
	
	public Date getClosedTime(){
		return this.closeTime;
	}
	
	
	public void setDescriptionAndComments() {
		this.description = new StringBuilder();
		this.commtents = new ArrayList<>();
		boolean first = true;
		Elements content = doc.select("div.edit-comment-hide");
		for(Element ele : content){
			if(first){
				this.description.append(ele.text());
				first = false;
			}
			else{
				this.commtents.add(ele.text());
			}
			
		}
	}

	public String PrintInfo() {
		StringBuilder info = new StringBuilder();
		info.append("\t<title>" + this.title + "</title>\n");
		info.append("\t<bugID>" + this.bugID + "</bugID>\n");
		info.append("\t<url>" + this.BR_url + "</url>\n");
		info.append("\t<labels>\n");
		for(String label : this.labels)
			info.append("\t\t<label>" + label + "</label>\n");
		info.append("\t</labels>\n");
		info.append("\t<assignees>" + this.assignees + "\t</assignees>\n");
		info.append("\t<developer>" + this.developer + "</developer>\n");
		info.append("\t<commters>" + this.commters.toString() + "</commters>\n");
		info.append("\t<number_commters>" + this.num_Comments + "</number_commters>\n");
		if(!("".equals(this.openTime) || this.openTime == null ))
			info.append("\t<openTime>" + this.openTime.toString() + "</openTime>\n");
		if(!("".equals(this.closeTime) || this.closeTime == null ))
			info.append("\t<closedTime>" + this.closeTime.toString() + "</closedTime>\n");
		info.append("\t<description>\n\t\t" + this.description.toString() + "\n\t</description>\n");
		for(String comment : this.commtents){
			info.append("\t<comment>\n\t\t" + comment + "\n\t</comment>\n");
		}
		return info.toString();
	}
}
