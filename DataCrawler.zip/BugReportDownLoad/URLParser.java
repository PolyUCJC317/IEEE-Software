package BugReportDownLoad;

import java.awt.image.RescaleOp;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.DefaultEditorKit.CopyAction;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class URLParser {
	public String urlPath;

	public URLParser() {
	}

	public static String getURLContent(String path, String charset) {

		StringBuilder sb = new StringBuilder();
		int reponseCode = 429;
		while (reponseCode == 429) {
			try {
				URL url = new URL(path);

				URLConnection urlConnection = url.openConnection();
				HttpURLConnection httpUrlConnection = (HttpURLConnection) urlConnection;

				httpUrlConnection.setDoOutput(true);

				httpUrlConnection.setDoInput(true);

				httpUrlConnection.setUseCaches(false);

				httpUrlConnection.setRequestProperty("Content-type", "application/x-java-serialized-object");

				httpUrlConnection.setRequestMethod("GET");

				httpUrlConnection.setConnectTimeout(30000);
				httpUrlConnection.setReadTimeout(30000);

				httpUrlConnection.connect();

				reponseCode = httpUrlConnection.getResponseCode();

				if (reponseCode == 429) {
					Thread.sleep(10000);
					continue;
				}
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(httpUrlConnection.getInputStream(), Charset.forName(charset)));

				String temp = "";
				while ((temp = reader.readLine()) != null) {
					sb.append(temp + "\n");
				}
			} catch (Exception e) {
				System.out.println("Error=======================" + path);
				e.printStackTrace();
			}
		}

		return sb.toString();
	}

	public static ArrayList<String> getBugLabel(String Content, String label) {
		ArrayList<String> bugLabel = new ArrayList<>();
		Pattern p = Pattern.compile("<a class=\"label label-link\" href=\"([\\S]+?)/labels/([\\S]+?)\"");
		Matcher m = p.matcher(Content);
		while (m.find()) {
			if (!(m.group(2) == null || "".equals(m.group(2)))) {
				if (m.group(2).toLowerCase().contains(label)) {
					String tmp = m.group(2);
					if (tmp.contains("%20"))
						tmp = "\"" + tmp.replaceAll("%20", "+") + "\"";
					bugLabel.add(tmp);
				}
			}
		}
		return bugLabel;
	}

	public static int getPageNum(String Content) {
		Pattern p = Pattern.compile("<div class=\"pagination\">[\\S ]+>([0-9]+?)</a> <a class=\"next_page\"");
		Matcher m = p.matcher(Content);
		int ans = 1;
		while (m.find()) {
			if (!(m.group(1) == null || "".equals(m.group(1)))) {
				ans = Integer.valueOf(m.group(1));
			}
		}
		return ans;
	}

	public static void copy(File folder) {
		String aimURL = "D:/PolyU/IEEE-Desktop-Mobile/dataset-100Apps/desktop2/" + folder.getName();
		File aim = new File(aimURL);
		aim.mkdirs();
		File[] issues = folder.listFiles();
		for (File issue : issues) {
			File aimIssule = new File(aimURL + "/" + issue.getName());
			try {
				String newIssue = aimURL + "/" + issue.getName();
				BufferedWriter writer = new BufferedWriter(new FileWriter(new File(newIssue)));
				BufferedReader reader = new BufferedReader(new FileReader(issue));
				String line = "";
				while((line = reader.readLine()) != null){
					if(line.equals("</Issue>")){
						writer.write(line+"\n");
						writer.close();
						reader.close();
						break;
					}
					writer.write(line+"\n");
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}


	public static void print(String repository, String[] labels, String rootPath) {
		// if(labels == null){
		// ArrayList<String> tmp =
		// URLParser.getBugLabel(URLParser.getURLContent("https://github.com" +
		// repository + "/labels", "utf-8"),"bug");
		// labels = (String[])tmp.toArray();
		// }
		//
		String tmpPath = repository.replaceAll("/", "_");
		File folder = new File(rootPath + tmpPath);
		if (folder.exists() && folder.listFiles().length > 0) {
			copy(folder);
			return;
		}

		int reportNum = 0;
		// for(String label : labels){
		for (int ttt = 0; ttt < 1; ttt++) {
			int idx = 1;
			int pageNum = 2;
			while (true) {
				if (idx > pageNum)
					break;
				// String url = "https://github.com" + repository +
				// "/issues?page=" +
				// String.valueOf(idx) +
				// "&q=is%3Aissue+is%3Aclosed+label%3A" + label;
				String url = "https://github.com/" + repository + "/issues?page=" + String.valueOf(idx)
						+ "&q=is%3Aissue+is%3Aclosed";
				// if(repository.equals("/TwidereProject/Twidere-Android"))
				System.out.println(url);
				String Content = URLParser.getURLContent(url, "utf-8");
				if (idx == 1) {
					pageNum = URLParser.getPageNum(Content);
				}
				idx++;

				Pattern p = Pattern.compile("<a href=\"([\\S]+?)\" class=\"link-gray-dark");
				Matcher m = p.matcher(Content);
				while (m.find()) {
					if (!(m.group(1) == null || "".equals(m.group(1)))) {
						if (!folder.exists())
							folder.mkdirs();
						BugReport.numberCnt++;
						String BugLink = "https://github.com" + m.group(1);
						BugInfo2 br = new BugInfo2(URLParser.getURLContent(BugLink, "utf-8"), BugLink);
						File floder = new File(rootPath + tmpPath);
						if (!floder.exists())
							floder.mkdirs();
						File file = new File(rootPath + tmpPath + "\\" + br.getBugID().replaceAll(" ", "") + ".xml");
						reportNum++;
						if (file.exists())
							continue;
//						FileOutputStream writerStream;
						BufferedWriter writer = null;
						try {
//							writerStream = new FileOutputStream(file);
//							writer = new BufferedWriter(new OutputStreamWriter(writerStream, "UTF-8"));
							writer = new BufferedWriter(new FileWriter(file));
							writer.write("<Issue>\n");
							writer.write(br.PrintInfo());
							writer.write("</Issue>\n");
							writer.close();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} finally {

						}
					}
				}
			}

		}

		System.out.println(repository + " -- finished -- Bug Report : " + reportNum);

	}
}
